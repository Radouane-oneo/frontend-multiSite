(function ($) {
  var submitFormRequest;
  $.fn.submitForm = function(form, triggeringElement, callback) {
    if (submitFormRequest){
      submitFormRequest.abort();
    }
    var url = form.attr('action');
    var data = form.serialize();

    if (triggeringElement) {
      data = '_triggering_element_name=' + triggeringElement.attr("name") + '&' + data;
    }

    data = data + '&op=ajax';

    submitFormRequest = $.ajax({
      type: 'POST',
      url: url,
      data: data,
      success: function(data){
        form.html($('#' + form.attr('id'), data).html());
        Drupal.attachBehaviors(form);
        if (callback){
          callback(data);
        }
      },
    });
  };


  Drupal.behaviors.dcbase = {
    detach: function (context) {

    },
    attach: function (context, settings) {
      $(document).ajaxStart(function(){
        $('body').css('cursor','wait');
      });

      $(document).ajaxStop(function(){
        $('body').css('cursor','default');
      });
    }
  }
})(jQuery);