(function ($) {

  Drupal.behaviors.dccart = {
    detach: function (context) {

    },
    attach: function (context, settings) {
      /*
      $('#dccart-cart-form .add-discount').once().click(function(){
        $.fn.submitForm($('#dccart-cart-form'),$(this));
        return false;
      });

      $('#dccart-cart-form select').once().change(function(){
        $.fn.submitForm($('#dccart-cart-form'),$(this));
      });
      $('#dccart-cart-form input[type="radio"]').once().click(function(){
        $.fn.submitForm($('#dccart-cart-form'),$(this));
      });
*/

      $('#dccart-cart-form .delete').once().click(function(){
        $(this).parents('.item').fadeOut();
      // $.fn.submitForm($('#dccart-cart-form'),$(this));
      // return false;
      });
      
      $('#dccart-cart-form .item .designtool').fancybox({
        width: 815,
        height: 610,
        padding: 5,
        margin: 0,
        scrolling: false,
        autoScale: false,
        hideOnOverlayClick: false,
        autoDimensions: false,
        onStart: function() {
          jQuery("#fancybox-outer").append("<div id='dt_preloader'></div>");
        },
        onComplete: function(){
        //  jQuery("#fancybox-outer").find("#dt_preloader").remove();
        }
      });

      $('#dccart-cart-form .discount input[type="text"]').bind("keydown", function(event) {
        var keycode = (event.keyCode ? event.keyCode : (event.which ? event.which : event.charCode));
        if (keycode == 13) {
          //$.fn.submitForm($('#dccart-cart-form'),$('#dccart-cart-form .discount input[type="submit"]'));
          $('#dccart-cart-form .discount input[type="submit"]').click();
          return false;
        } else  {
          return true;
        }
      });

    }
  }
})(jQuery);


function designtoolCallback(){

  window.location.href = window.location.href;
}
