(function ($) {

  Drupal.behaviors.dccheckout = {
    detach: function (context) {

    },
    attach: function(context, settings) {


      $('#dccheckout-checkout-form #edit-personal input', context).focus(function(){
        $('#block-dccheckout-progress .personal').addClass('done');
      });

      $('#dccheckout-checkout-form #edit-invoice input, #dccheckout-checkout-form #edit-invoice select', context).focus(function(){
        $('#block-dccheckout-progress .invoice').addClass('done');
      });

      $('#dccheckout-checkout-form #edit-delivery input, #dccheckout-checkout-form #edit-delivery select', context).focus(function(){
        $('#block-dccheckout-progress .delivery').addClass('done');
      });

      $('#dccheckout-checkout-form #edit-payment input, #dccheckout-checkout-form #edit-payment select', context).focus(function(){
        $('#block-dccheckout-progress .payment').addClass('done');
      });

       $('#dccheckout-checkout-form .form-item-terms input', context).focus(function(){
        $('#block-dccheckout-progress .review').addClass('done');
      });

  
      $('#dccheckout-checkout-form .form-item-delivery-address select').change(function(){
        setDeliveryAddress($(this).val());
      });
      
      $('#dccheckout-checkout-form .form-item-invoice-address select').once().change(function(){
        setInvoiceAddress($(this).val());
      });

      $('#dccheckout-checkout-form .form-item-invoice-country select' ).once().change(function(){
        var url = '/js/country/' + $(this).val();
        $.getJSON(url, null, function (data){
          $('.form-item-invoice-vatNumber .country').val(data.vatPrefix).trigger('change');
        });
      });


      $('#dccheckout-checkout-form .form-item-invoice-vatNumber').bind('change', function() {
        $.fn.submitForm($('#dccheckout-checkout-form'),$(this));
      })

      $('#dccheckout-checkout-form input[type="radio"]' ).change(function(){
        $.fn.submitForm($('#dccheckout-checkout-form'),$(this));
      });


      if (!$('#dccheckout-checkout-form #edit-invoice-shipment-differs').is(':checked')){
        $('#dccheckout-checkout-form .delivery').hide();
      }

      $('#dccheckout-checkout-form #edit-invoice-shipment-differs').once().click(function(){
        if ($(this).is(':checked')){
          $('#dccheckout-checkout-form .delivery').slideDown();
        }
        else{
          $('#dccheckout-checkout-form .delivery').slideUp();
        }
      });

    }
  }


  function setDeliveryAddress(id){
    if (id == 0) {
      $('#dccheckout-checkout-form .form-item-delivery-address select').val(0);
      $('#dccheckout-checkout-form .form-item-delivery-company input').val('');
      $('#dccheckout-checkout-form .form-item-delivery-name input').val('');
      $('#dccheckout-checkout-form .form-item-delivery-country select').val(0);
      $('#dccheckout-checkout-form .form-item-delivery-street input').val('');
      $('#dccheckout-checkout-form .form-item-delivery-postalCode input').val('');
      $('#dccheckout-checkout-form .form-item-delivery-city input').val('');
      $('#dccheckout-checkout-form .form-item-delivery-phone input').val('');
    }
    else{
      var url = '/js/account/address/' + id;
      $.getJSON(url, null, function (data){
        $('#dccheckout-checkout-form .form-item-delivery-address select').val(data.id);
        $('#dccheckout-checkout-form .form-item-delivery-company input').val(data.company);
        $('#dccheckout-checkout-form .form-item-delivery-name input').val(data.name);
        $('#dccheckout-checkout-form .form-item-delivery-country select').val(data.country);
        $('#dccheckout-checkout-form .form-item-delivery-street input').val(data.street);
        $('#dccheckout-checkout-form .form-item-delivery-postalCode input').val(data.postalCode);
        $('#dccheckout-checkout-form .form-item-delivery-city input').val(data.city);
        $('#dccheckout-checkout-form .form-item-delivery-phone input').val(data.phone);
      });
    }
  }

  function setInvoiceAddress(id){
    if (id == 0) {
      $('#dccheckout-checkout-form .form-item-invoice-address select').val(0);
      $('#dccheckout-checkout-form .form-item-invoice-company input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-name input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-country select').val(0);
      $('#dccheckout-checkout-form .form-item-invoice-street input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-postalCode input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-city input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-phone input').val('');
      $('#dccheckout-checkout-form .form-item-invoice-vatNumber .country').val('');
      $('#dccheckout-checkout-form .form-item-invoice-vatNumber .number').val('');
    }
    else{
      var url = '/js/account/address/' + id;
      $.getJSON(url, null, function (data){
        $('#dccheckout-checkout-form .form-item-invoice-address select').val(data.id);
        $('#dccheckout-checkout-form .form-item-invoice-company input').val(data.company);
        $('#dccheckout-checkout-form .form-item-invoice-name input').val(data.name);
        $('#dccheckout-checkout-form .form-item-invoice-country select').val(data.country);
        $('#dccheckout-checkout-form .form-item-invoice-street input').val(data.street);
        $('#dccheckout-checkout-form .form-item-invoice-postalCode input').val(data.postalCode);
        $('#dccheckout-checkout-form .form-item-invoice-city input').val(data.city);
        $('#dccheckout-checkout-form .form-item-invoice-phone input').val(data.phone);
        $('#dccheckout-checkout-form .form-item-invoice-vatNumber .country').val(data.vatNumber.country);
        $('#dccheckout-checkout-form .form-item-invoice-vatNumber .number').val(data.vatNumber.number);
        $('#dccheckout-checkout-form .form-item-invoice-vatNumber .number').trigger('change');
      });
    }
    $('#dccheckout-checkout-form .form-type-vatfield').vatfieldValidate();
   // pccheckout_submit_form($('#pccheckout-checkout-form'), $('#dccheckout-checkout-form .form-type-vatfield .number'));
  }

  function toggleInvoiceAddress(){
    if ($("#dccheckout-checkout-form .form-item-payment-needinvoice input").attr('checked')){
      $('#dccheckout-checkout-form .payment-invoice-wrapper').slideDown();
    }
    else{
      $('#dccheckout-checkout-form .payment-invoice-wrapper').slideUp();
    }
  }



})(jQuery);

