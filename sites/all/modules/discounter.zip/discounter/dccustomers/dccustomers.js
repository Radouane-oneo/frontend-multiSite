(function ($) {

  Drupal.behaviors.dccustomers= {
    detach: function (context) {

    },
    attach: function(context, settings) {
      $('#dccustomers-address-form .form-item-country select', context ).once().change(function(){
        var url = '/js/country/' + $(this).val();
        $.getJSON(url, null, function (data){
          $('.form-item-vatNumber .country', context).val(data.vatPrefix).trigger('change');
        });
      });

    }
  }

})(jQuery);

