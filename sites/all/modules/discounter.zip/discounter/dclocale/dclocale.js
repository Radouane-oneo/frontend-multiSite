(function ($) {

  Drupal.behaviors.dclocale= {
    detach: function (context) {

    },
    attach: function(context, settings) {
      $('#block-locale-language').once('dclocale', function(){
        var content = $('.content', this);
        var block = $(this);
        var list = $('ul', content);
        var activeclass = $('li.active', list).attr('class');
        var current = $('<div class="current"/>').attr('class', activeclass);

        list.hide();

        list.css({
          'position' : 'absolute',
          'z-index' : 2000,
        });
        //list.width(block.width());
        list.hover(
          function () {
            
          },
          function () {
            $(this).slideUp();
          }
        );

        $('li', list).css({
          'display' : 'block',
          'float' : 'none',          
        });

        $('li.active',list).hide();

        current.prepend($('li.active', content).html());

        content.prepend(current);

        current.click(function(){
          list.slideDown();
          return false;
        });

      });
    }
  }

})(jQuery);

