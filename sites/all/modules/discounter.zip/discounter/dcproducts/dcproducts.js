(function ($) {
  Drupal.behaviors.dcproducts = {
    detach: function (context) {

    },
    attach: function (context, settings) {
      $('#dcproducts-product-form tr.custom td.qty', context).replaceWith($('#dcproducts-product-form .form-item-custom-quantity', context));
      $('#dcproducts-product-form .form-item-custom-quantity input', context).once().keyup(function(){
          $('#dcproducts-product-form table tr.custom input', context).attr('checked', true);
      });
/*
      $('#block-dcproducts-files a', context).fancybox({
        width: 800,
        height: 740,
        padding: 0,
        margin: 0,
        scrolling: 'auto',
        autoScale: false,
        hideOnOverlayClick: false,
        type : 'iframe',
        autoDimensions: false,
      });

*/
    }
  }
})(jQuery);