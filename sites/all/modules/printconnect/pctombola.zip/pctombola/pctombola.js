(function ($) {

    Drupal.behaviors.pctombola = {
        detach: function (context) {

        },


        attach: function (context, settings) {
            $(document).find('#edit-questions > .form-item-Q1').attr('id', 'Q1');
            $(document).find('#edit-questions > .form-item-Q2').attr('id', 'Q2');
            $(document).find('#edit-questions > .form-item-Q3').attr('id', 'Q3');


            $('#fancybox-content #edit-send').live('click', function () {



                $('#fancybox-content  input[id^="edit"]').each(function () {
                    id = $(this).attr('id');
                    val = $(this).val();
                    $('.block-pctombola').find("#" + id).val(val);

                    if ($(this).attr('type') == 'checkbox') {
                        $('.block-pctombola').find("#" + id).attr('checked', true);
                    }
                });
                $('.block-pctombola #edit-send').trigger('mousedown');
            });




            if ($.fancybox) {
                $('#edit-paticiperbtn').fancybox({
                    width: 960,
                    height: 660,
                    padding: 0,
                    margin: 0,
                    scrolling: false,
                    autoScale: false,
                    hideOnOverlayClick: true,
                    autoDimensions: true,
                    modal: false,
                    content: $("#edit-globalform").html().replace("submit", "button"),
                    onComplete: function (links, index) {

                        $('a.playLink').click(function () {
                            $(document).find('#edit-introholder').fadeOut().hide();
                            $(document).find('#edit-questions , #edit-questions > .form-item-Q1').fadeIn().show();
                            $(document).find('#edit-next').show();
                            return false;
                        });


                        $(document).find('#edit-next').click(function () {
                            if ($(document).find('#Q1').is(":visible")) {
                                $(document).find('#Q1').fadeOut().hide();
                                $(document).find('#Q2').fadeIn().show();
                                $(document).find('#edit-previous').show();

                            } else
                            if ($(document).find('#Q2').is(":visible")) {
                                $(document).find('#Q2').fadeOut().hide();
                                $(document).find('#Q3').fadeIn().show();

                            } else
                            if ($(document).find('#Q3').is(":visible")) {
								$(document).find('#Q3').fadeOut().hide();
                                $(document).find('#edit-userform').fadeIn().show();

                                $(document).find('#edit-next').fadeOut().hide();
                                $(document).find('#edit-send').fadeIn().show();

                            }

                        });

                        $(document).find('#edit-previous').click(function () {
                            $(document).find('#edit-send').hide();
                            if ($(document).find('#edit-userform').is(":visible")) {
                                $(document).find('#edit-userform').fadeOut().hide();
                                $(document).find('#Q3').fadeIn().show();
                                $(document).find('#edit-next').show();


                            } else
                            if ($(document).find('#Q3').is(":visible")) {
                                $(document).find('#Q3').fadeOut().hide();
                                $(document).find('#Q2').fadeIn().show();

                            } else
                            if ($(document).find('#Q2').is(":visible")) {
                                $(document).find('#Q2').fadeOut().hide();
                                $(document).find('#Q1').fadeIn().show();

                                $(this).hide();


                            }

                        });

                        $(document).find('#edit-custom-0').click(function (e) {
                            $(document).find('.form-item-nameCompany').fadeOut(200);
                            $(document).find('.form-item-sectorCompany').fadeOut(200);
                        });
                        $(document).find('#edit-custom-1').click(function (e) {
                            $(document).find('.form-item-nameCompany').fadeIn(200).show();
                            $(document).find('.form-item-sectorCompany').fadeIn(200).show();
                        });




                    }

                });


            }




        }
    }
})(jQuery);